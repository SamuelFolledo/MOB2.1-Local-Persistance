//
//  CategoryListController.swift
//  News
//
//  Created by Mustafa on 06/05/20.
//  Copyright © 2020 Mustafa. All rights reserved.
//

import UIKit
import CloudKit

class CategoryListController: UITableViewController {
    
    var records: [CKRecord] = []
    
    var selectedCategories: [CKRecord] = []
    var completionHandler: (([CKRecord.ID]) -> Void)?
    
    typealias ListDataSource = UITableViewDiffableDataSource<Int, CKRecord>
    var dataSource: ListDataSource!
    
    init(_ completionHandler: (([CKRecord.ID]) -> Void)? = nil) {
        self.completionHandler = completionHandler
        super.init(style: .insetGrouped)
    }
    
    required init?(coder: NSCoder) {
        fatalError()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationItem.largeTitleDisplayMode = .never
        navigationItem.rightBarButtonItem = UIBarButtonItem(
            barButtonSystemItem: .add,
            target: self,
            action: #selector(addCategoryButtonTapped))
        
        tableView.contentInset = .init(top: 16, left: 0, bottom: 16, right: 0)
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
        let refreshControl = UIRefreshControl()
        refreshControl.addTarget(
            self,
            action: #selector(refresh),
            for: .valueChanged
        )
        tableView.refreshControl = refreshControl

        setupDataSource()
        fetchRecords()
    }
    
    @objc func addCategoryButtonTapped() {
        let controller = CreateCategoryController()
        navigationController?.pushViewController(controller, animated: true)
    }
    
    @objc func refresh() {
        fetchRecords()
    }
}

extension CategoryListController {
    
    func setupDataSource() {
        dataSource = ListDataSource.init(
            tableView: tableView,
            cellProvider: { [weak self] tableView, indexPath, record in
                let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
                cell.textLabel?.text = record[.title] as? String
                cell.accessoryType = self?.selectedCategories.contains(record) ?? true ?
                    .checkmark : .none
                return cell
        })
    }
    
    func updateDataSource(animatingDifference: Bool = true) {
        var snapshot = NSDiffableDataSourceSnapshot<Int, CKRecord>()
        snapshot.appendSections([0])
        snapshot.appendItems(records, toSection: 0)
        dataSource.apply(snapshot, animatingDifferences: animatingDifference)
    }
}

extension CategoryListController {
    
    func fetchRecords(_ cursor: CKQueryOperation.Cursor? = nil) {
        
        #warning("step 4:- it is the same as step two, except the type is hardcoded to `Category` here")
        
//        if cursor == nil {
//            records.removeAll()
//        }
//
//        let operation: CKQueryOperation
//
//        if let cursor = cursor {
//            operation = CKQueryOperation(cursor: cursor)
//        } else {
//            let query = CKQuery(recordType: .Category, predicate: NSPredicate(value: true))
//            operation = CKQueryOperation(query: query)
//        }
//
//        operation.queryCompletionBlock = { [weak self] cursor, error in
//            if let cursor = cursor {
//                self?.fetchRecords(cursor)
//            } else {
//                DispatchQueue.main.async { [weak self] in
//                    self?.updateDataSource()
//                }
//            }
//        }
//
//        operation.recordFetchedBlock = { [weak self] record in
//            self?.records.append(record)
//        }
//
//        CKContainer.shared.publicCloudDatabase.add(operation)
    }
}

extension CategoryListController {
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        guard let category = dataSource.itemIdentifier(for: indexPath) else { return }
        if let index = selectedCategories.firstIndex(of: category) {
            selectedCategories.remove(at: index)
        } else {
            selectedCategories.append(category)
        }
        completionHandler?(selectedCategories.map { $0.recordID })
        updateDataSource(animatingDifference: false)
        tableView.deselectRow(at: indexPath, animated: true)
    }
}
