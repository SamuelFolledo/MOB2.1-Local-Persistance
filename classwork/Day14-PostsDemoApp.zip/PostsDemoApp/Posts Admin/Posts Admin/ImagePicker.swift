//
//  Copyright © 2020 Mustafa Yusuf. All rights reserved.
//

import UIKit

open class ImagePicker: NSObject {

    private let pickerController: UIImagePickerController
    private weak var presentationController: UIViewController?
    
    var completion: ((_ image: UIImage) -> Void)

    public init(presentationController: UIViewController, _ completion: @escaping ((_ image: UIImage) -> Void)) {
        self.pickerController = UIImagePickerController()
        self.completion = completion
        super.init()

        self.presentationController = presentationController

        self.pickerController.delegate = self
        self.pickerController.allowsEditing = true
        self.pickerController.mediaTypes = ["public.image"]
    }

    public func present(from sourceView: UIView) {

        let alertController = UIAlertController(title: nil, message: nil, preferredStyle: .actionSheet)

        let sources: [UIImagePickerController.SourceType] = [.camera, .photoLibrary, .savedPhotosAlbum]
        let values: [String] = ["Take photo", "Camera roll", "Photo library"]
        for source in sources.enumerated() {
            if UIImagePickerController.isSourceTypeAvailable(source.element) {
                let action = UIAlertAction(title: values[source.offset], style: .default) { [weak self] _ in
                    if let self = self {
                        self.pickerController.sourceType = source.element
                        self.presentationController?.present(self.pickerController, animated: true)
                    }
                }
                alertController.addAction(action)
            }
        }

        alertController.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))

        alertController.popoverPresentationController?.sourceView = sourceView
        alertController.popoverPresentationController?.sourceRect = sourceView.bounds
        alertController.popoverPresentationController?.permittedArrowDirections = [.down, .up]

        self.presentationController?.present(alertController, animated: true)
    }

    private func pickerController(_ controller: UIImagePickerController, didSelect image: UIImage?) {
        controller.dismiss(animated: true, completion: nil)
        if let image = image {
            completion(image)
        }
    }
}

//MARK:- UIImagePickerControllerDelegate

extension ImagePicker: UIImagePickerControllerDelegate {

    public func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        self.pickerController(picker, didSelect: nil)
    }

    public func imagePickerController(_ picker: UIImagePickerController,
                                      didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey: Any]) {
        guard let image = info[.editedImage] as? UIImage else {
            return self.pickerController(picker, didSelect: nil)
        }
        self.pickerController(picker, didSelect: image)
    }
}

//MARK:- UINavigationControllerDelegate

extension ImagePicker: UINavigationControllerDelegate {

}
