//
//  ListController.swift
//  News Admin
//
//  Created by Mustafa Yusuf on 06/05/20.
//  Copyright © 2020 Mustafa Yusuf. All rights reserved.
//

import UIKit
import CloudKit

class ListController: UITableViewController {

    typealias ListDataSource = UITableViewDiffableDataSource<Int, CKRecord>
    var dataSource: ListDataSource!
    
    let type: CKRecord.RecordType
    
    var records: [CKRecord] = []
    
    init(_ type: CKRecord.RecordType) {
        self.type = type
        super.init(style: .insetGrouped)
    }
    
    required init?(coder: NSCoder) {
        fatalError()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        title = type
        navigationItem.largeTitleDisplayMode = .always
        navigationController?.navigationBar.prefersLargeTitles = true
        navigationItem.rightBarButtonItem = .init(barButtonSystemItem: .add, target: self, action: #selector(addNewTypeTapped))
        
        tableView.contentInset = .init(top: 16, left: 0, bottom: 16, right: 0)
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
        let refreshControl = UIRefreshControl()
        refreshControl.addTarget(
            self,
            action: #selector(refresh),
            for: .valueChanged
        )
        tableView.refreshControl = refreshControl
        
        setupDataSource()
        fetchRecords()
    }
    
    @objc func refresh() {
        fetchRecords()
    }
    
    @objc func addNewTypeTapped() {
        switch type {
        case .Post:
            navigationController?.pushViewController(CreatePostController(), animated: true)
        case .Category:
            navigationController?.pushViewController(CreateCategoryController(), animated: true)
        default:
            fatalError()
        }
    }
}

extension ListController {
    
    func setupDataSource() {
        dataSource = ListDataSource.init(
            tableView: tableView,
            cellProvider: { tableView, indexPath, record in
                let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
                cell.textLabel?.text = record[.title] as? String
                cell.accessoryType = .disclosureIndicator
                return cell
        })
        
        updateDataSource()
    }
    
    func updateDataSource() {
        var snapshot = NSDiffableDataSourceSnapshot<Int, CKRecord>()
        snapshot.appendSections([0])
        snapshot.appendItems(records, toSection: 0)
        dataSource.apply(snapshot)
    }
}

extension ListController {
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        guard let record = dataSource.itemIdentifier(for: indexPath) else {
            return
        }
        switch type {
        case .Category:
            navigationController?.pushViewController(CreateCategoryController(record: record), animated: true)
        case .Post:
            navigationController?.pushViewController(CreatePostController(record: record), animated: true)
        default:
            fatalError()
        }
    }
}

extension ListController {
    
    func fetchRecords(_ cursor: CKQueryOperation.Cursor? = nil) {
        
        #warning("step 2:- fetch all records with the mentioned `type`")
        
//        if cursor == nil {
//            records.removeAll()
//        }
//
//        let operation: CKQueryOperation
//
//        if let cursor = cursor {
//            operation = CKQueryOperation(cursor: cursor)
//        } else {
//            let query = CKQuery(recordType: type, predicate: NSPredicate(value: true))
//            operation = CKQueryOperation(query: query)
//        }
//
//        operation.queryCompletionBlock = { [weak self] cursor, error in
//            if let cursor = cursor {
//                self?.fetchRecords(cursor)
//            } else {
//                DispatchQueue.main.async { [weak self] in
//                    self?.tableView.refreshControl?.endRefreshing()
//                    self?.updateDataSource()
//                }
//            }
//        }
//
//        operation.recordFetchedBlock = { [weak self] record in
//            self?.records.append(record)
//        }
//
//        CKContainer.shared.publicCloudDatabase.add(operation)
    }
}

enum CKRecordKey: String {
    //Category
    case title, order
    //Post
    case thumbnail, sourceName, sourceUrl, url, date, categories
}

extension CKRecord {
    
    subscript(key: CKRecordKey) -> Any? {
        get {
            return self[key.rawValue]
        }
        set {
            self[key.rawValue] = newValue as? CKRecordValue
        }
    }
}
