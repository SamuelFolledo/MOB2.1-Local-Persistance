//
//  CreatePostController.swift
//  News
//
//  Created by Mustafa on 05/05/20.
//  Copyright © 2020 Mustafa. All rights reserved.
//

import UIKit
import CloudKit

class CreatePostController: UIViewController {
    
    var postRecord: CKRecord?
    var postTitle: String?
    var postSourceName: String?
    var postSourceUrl: URL?
    var postUrl: URL?
    var postDate: Date? = Date()
    var postThumbnail: UIImage? {
        didSet {
            if postThumbnail == nil {
                selectImageButton.setTitle("Tap to select image", for: .normal)
            } else {
                selectImageButton.setTitle("Tap to change image", for: .normal)
            }
        }
    }
    var categories: [CKRecord.ID] = [] {
        didSet {
            if categories.isEmpty {
                selectCategoriesButton.setTitle("Tap to select categories", for: .normal)
            } else {
                selectCategoriesButton.setTitle(
                    String(describing: categories.count) + " categor\(categories.count == 1 ? "y" : "ies") selected",
                    for: .normal
                )
            }
        }
    }
    
    var imagePicker: ImagePicker?
    
    lazy var stackView: UIStackView = {
        let stack = UIStackView()
        stack.translatesAutoresizingMaskIntoConstraints = false
        stack.axis = .vertical
        stack.distribution = .fill
        stack.alignment = .fill
        stack.spacing = 16
        return stack
    }()
    
    lazy var selectCategoriesButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("Tap to select categories", for: .normal)
        button.contentHorizontalAlignment = .leading
        button.titleLabel?.font = UIFont.preferredFont(forTextStyle: .subheadline)
        button.addTarget(self, action: #selector(didTapSelectCategories), for: .touchUpInside)
        return button
    }()
    
    lazy var selectImageButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("Tap to select image", for: .normal)
        button.contentHorizontalAlignment = .leading
        button.titleLabel?.font = UIFont.preferredFont(forTextStyle: .subheadline)
        button.addTarget(self, action: #selector(didTapSelectImage), for: .touchUpInside)
        return button
    }()
    
    init(record: CKRecord? = nil) {
        self.postRecord = record
        self.postTitle = postRecord?[.title] as? String ?? ""
        self.postUrl = URL(string: postRecord?[.url] as? String ?? "")
        self.postSourceName = postRecord?[.sourceName] as? String ?? ""
        self.postSourceUrl = URL(string: postRecord?[.sourceUrl] as? String ?? "")
        self.categories = (postRecord?[.categories] as? [CKRecord.Reference])?.map { $0.recordID } ?? []
        if let asset = postRecord?[.thumbnail] as? CKAsset,
            let fileUrl = asset.fileURL,
            let data = try? Data(contentsOf: fileUrl) {
            self.postThumbnail = UIImage(data: data)
        }
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        navigationItem.largeTitleDisplayMode = .never
        navigationItem.rightBarButtonItem = UIBarButtonItem(
            barButtonSystemItem: .save,
            target: self,
            action: #selector(createOrUpdatePost)
        )
        navigationItem.rightBarButtonItem?.style = .done
        
        let textFields = ["Title", "Post link", "Source, e.g. The Verge, etc", "Link of source, e.g. https://theverge.com"]
        
        view.backgroundColor = .systemBackground
        view.addSubview(stackView)
        
        NSLayoutConstraint.activate([
            stackView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 16),
            stackView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 16),
            stackView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -16),
        ])

        textFields.enumerated().forEach { offset, placeholder in
            let textField = UITextField()
            textField.borderStyle = .roundedRect
            textField.placeholder = placeholder
            textField.tag = offset
            stackView.addArrangedSubview(textField)
        }
        stackView.addArrangedSubview(selectCategoriesButton)
        stackView.addArrangedSubview(selectImageButton)
        
        (stackView.arrangedSubviews[0] as? UITextField)?.text = postTitle
        (stackView.arrangedSubviews[1] as? UITextField)?.text = postUrl?.absoluteString
        (stackView.arrangedSubviews[2] as? UITextField)?.text = postSourceName
        (stackView.arrangedSubviews[3] as? UITextField)?.text = postSourceUrl?.absoluteString
    }
    
    @objc func didTapSelectCategories() {
        let controller = CategoryListController { categories in
            self.categories = categories
        }
        navigationController?.pushViewController(controller, animated: true)
    }
    
    @objc func didTapSelectImage() {
        imagePicker = ImagePicker(presentationController: self) { image in
            self.postThumbnail = image
        }
        imagePicker?.present(from: selectImageButton)
    }
    
    @objc func createOrUpdatePost() {
        postTitle = (stackView.arrangedSubviews[0] as? UITextField)?.text
        postUrl = URL(string: (stackView.arrangedSubviews[1] as? UITextField)?.text ?? "")
        postSourceName = (stackView.arrangedSubviews[2] as? UITextField)?.text
        postSourceUrl = URL(string: (stackView.arrangedSubviews[3] as? UITextField)?.text ?? "")
        
        #warning("step 5:- creating our post")
        
//        guard let title = postTitle, let url = postUrl, !categories.isEmpty else {
//            (stackView.arrangedSubviews[0] as? UITextField)?.textColor = .systemRed
//            return
//        }
//
//        let record = postRecord ?? CKRecord(recordType: .Post, recordID: .init(recordName: UUID().uuidString))
//        record[.title] = title
//        record[.url] = url.absoluteString
//        record[.sourceName] = postSourceName
//        record[.sourceUrl] = postSourceUrl?.absoluteString
//        record[.date] = postDate
//        record[.categories] = categories.map { CKRecord.Reference(recordID: $0, action: .none) }
//
//        let temporaryUrl = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
//        if let data = postThumbnail?.jpegData(compressionQuality: 0.1) {
//            do {
//                try data.write(to: temporaryUrl)
//                record[.thumbnail] = CKAsset(fileURL: temporaryUrl)
//            } catch {
//                fatalError()
//            }
//        }
//
//        let operation = CKModifyRecordsOperation(recordsToSave: [record], recordIDsToDelete: nil)
//        operation.modifyRecordsCompletionBlock = { savedRecords, _, error in
//
//            if let error = error {
//                fatalError(error.localizedDescription)
//            } else if let records = savedRecords {
//                //done
//                print(records)
//                DispatchQueue.main.async { [weak self] in
//                    self?.navigationController?.popViewController(animated: true)
//                }
//            } else {
//                fatalError()
//            }
//        }
//        CKContainer.shared.publicCloudDatabase.add(operation)
    }
    
}
