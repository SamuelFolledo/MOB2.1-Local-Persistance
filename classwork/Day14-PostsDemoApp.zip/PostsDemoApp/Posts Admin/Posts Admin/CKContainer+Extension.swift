//
//  CKContainer+Extension.swift
//  News Admin
//
//  Created by Mustafa Yusuf on 19/05/20.
//  Copyright © 2020 Mustafa Yusuf. All rights reserved.
//

import UIKit
import CloudKit

extension CKContainer {
    static var shared: CKContainer {
        #warning("step 1:- replace this string with your container identifer")
        return CKContainer(identifier: "iCloud.com.something")
    }
}

extension CKRecord.RecordType {    
    public static var Category: String = "Category"
    public static var Post: String = "Post"
}
