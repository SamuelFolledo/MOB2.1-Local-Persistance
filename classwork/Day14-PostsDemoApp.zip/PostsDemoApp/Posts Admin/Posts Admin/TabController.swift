//
//  TabController.swift
//  News Admin
//
//  Created by Mustafa Yusuf on 06/05/20.
//  Copyright © 2020 Mustafa Yusuf. All rights reserved.
//

import UIKit

class TabController: UITabBarController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tabBar.tintColor = .systemPink
        
        let categoriesController = ListController(.Category)
        categoriesController.tabBarItem = UITabBarItem(
            title: "Categories",
            image: UIImage(systemName: "rectangle.fill.on.rectangle.angled.fill"),
            selectedImage: nil
        )
        
        let homeController = ListController(.Post)
        homeController.tabBarItem = UITabBarItem(
            title: "Posts",
            image: UIImage(systemName: "rectangle.3.offgrid.fill"),
            selectedImage: nil
        )
        
        setViewControllers([
            UINavigationController(rootViewController: categoriesController),
            UINavigationController(rootViewController: homeController)
        ], animated: true)
    }
}
