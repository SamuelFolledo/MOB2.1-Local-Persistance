//
//  CreateCategoryController.swift
//  News
//
//  Created by Mustafa on 05/05/20.
//  Copyright © 2020 Mustafa. All rights reserved.
//

import UIKit
import CloudKit

class CreateCategoryController: UIViewController {
    
    var categoryRecord: CKRecord?
    var categoryTitle: String
    var categoryOrder: Int16
    
    lazy var stackView: UIStackView = {
        let stack = UIStackView()
        stack.translatesAutoresizingMaskIntoConstraints = false
        stack.axis = .vertical
        stack.distribution = .fill
        stack.alignment = .fill
        stack.spacing = 16
        return stack
    }()
    
    init(record: CKRecord? = nil) {
        self.categoryRecord = record
        self.categoryTitle = categoryRecord?[.title] as? String ?? ""
        self.categoryOrder = categoryRecord?[.order] as? Int16 ?? 0
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
                
        navigationItem.largeTitleDisplayMode = .never
        navigationItem.rightBarButtonItem = UIBarButtonItem(
            barButtonSystemItem: .save,
            target: self,
            action: #selector(createOrUpdateCategory)
        )
        navigationItem.rightBarButtonItem?.style = .done
        
        let textFields = ["Title", "Order"]
        
        view.backgroundColor = .systemBackground
        view.addSubview(stackView)
        
        NSLayoutConstraint.activate([
            stackView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 16),
            stackView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 16),
            stackView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -16),
        ])
        
        textFields.enumerated().forEach { offset, placeholder in
            let textField = UITextField()
            textField.borderStyle = .roundedRect
            textField.placeholder = placeholder
            textField.tag = offset
            stackView.addArrangedSubview(textField)
        }
        (stackView.arrangedSubviews[0] as? UITextField)?.text = categoryTitle
        (stackView.arrangedSubviews[1] as? UITextField)?.text = String(describing: categoryOrder)
    }
    
    @objc func createOrUpdateCategory() {
        categoryTitle = (stackView.arrangedSubviews[0] as? UITextField)?.text ?? ""
        categoryOrder = Int16((stackView.arrangedSubviews[1] as? UITextField)?.text ?? "0") ?? 0

        #warning("step 3:- create our Category record")
//        let record = categoryRecord ?? CKRecord(recordType: "Category", recordID: .init(recordName: UUID().uuidString))
//        record["title"] = categoryTitle
//        record["order"] = categoryOrder
//
//
//        let operation = CKModifyRecordsOperation(recordsToSave: [record], recordIDsToDelete: nil)
//        operation.modifyRecordsCompletionBlock = { savedRecords, deletedRecordIds, error in
//
//            if let error = error {
//                fatalError(error.localizedDescription)
//            } else if let records = savedRecords {
//                //done
//                print(records)
//                DispatchQueue.main.async { [weak self] in
//                    self?.navigationController?.popViewController(animated: true)
//                }
//            } else {
//                fatalError()
//            }
//        }
//        CKContainer.shared.publicCloudDatabase.add(operation)
        
    }
    
}
